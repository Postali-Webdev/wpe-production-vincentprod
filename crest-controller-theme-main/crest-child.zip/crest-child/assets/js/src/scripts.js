jQuery(function ($) {
    "use strict";

    $(document).ready(function () {
        console.log('child scripts ready!');
    });

});