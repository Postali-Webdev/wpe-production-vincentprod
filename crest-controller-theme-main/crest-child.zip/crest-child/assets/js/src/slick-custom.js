jQuery(function ($) {
    "use strict";

});