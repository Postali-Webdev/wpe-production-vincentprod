<?php

add_action('wp_enqueue_scripts', 'postali_child_scripts');
function postali_child_scripts() {

    wp_enqueue_style( 'child-stylesheet', get_stylesheet_directory_uri() . '/style.css' ); // Enqueue Child theme style sheet (theme info)
    wp_enqueue_style( 'child-styles', get_stylesheet_directory_uri() . '/assets/css/styles.css'); // Enqueue Child theme styles.css
    
    // Compiled .js using Grunt.js
    wp_register_script('child-custom-scripts', get_stylesheet_directory_uri() . '/assets/js/scripts.min.js',array('jquery'), null, true); 
    wp_enqueue_script('child-custom-scripts');
    
    //slick
    wp_register_script('child-slick-custom', get_stylesheet_directory_uri() . '/assets/js/slick-custom.min.js',array('jquery'), null, true); 
    wp_enqueue_script('childslick-custom');
    
}